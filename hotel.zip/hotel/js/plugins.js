$(document).ready(function(){
    "use strict";
    $(window).resize(function () {
        $('html')
            .height($(window).height());
    });
    $('html')
        .height($(window).height());
    
    // Nice Scroll
    $("html").niceScroll();
      
    $(".carousel").carousel({
       interval:6000
  });
  
});