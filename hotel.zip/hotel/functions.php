<?php

  function main() {
      //Style
      wp_enqueue_style('css', get_stylesheet_uri());
      wp_enqueue_style('bootstrap.min', get_template_directory_uri().'/css/bootstrap.min.css');
      wp_enqueue_style('font-awesome', get_template_directory_uri().'/css/font-awesome.css');
      wp_enqueue_style('hover-min', get_template_directory_uri().'/css/hover-min.css');
      wp_enqueue_style('animate', get_template_directory_uri().'/css/animate.css');
      wp_enqueue_style('style', get_template_directory_uri().'/css/style.css');
      //Script
      wp_enqueue_script('jquery-1.12.1.min', get_template_directory_uri().'/js/jquery-1.12.1.min.js', array());
      wp_enqueue_script('bootstrap.min', get_template_directory_uri().'/js/bootstrap.min.js', array(jquery), 'null', true);
      wp_enqueue_script('jquery.nicescroll.min', get_template_directory_uri().'/js/jquery.nicescroll.min.js', array(jquery), 'null', true);
      wp_enqueue_script('plugins', get_template_directory_uri().'/js/plugins.js', array(jquery), 'null', true);
      
      wp_enqueue_script('respond.min', get_template_directory_uri().'/jhttps://oss.maxcdn.com/html5shiv/3.7.2/html5shiv.min.js');
      wp_script_add_data('respond.min', 'conditional', 'lt IE 9');
      wp_enqueue_script('html5shiv.min', get_template_directory_uri().'/https://oss.maxcdn.com/respond/1.4.2/respond.min.js');
      wp_script_add_data('html5shiv.min', 'conditional', 'lt IE 9');
  }

    add_action('wp_enqueue_scripts', 'main');