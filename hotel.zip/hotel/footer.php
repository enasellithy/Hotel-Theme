 <!--Start Carousel-->
    <div id="myCarousel" class="carousel slide" data-ride="carousel">
        <!-- Indicators -->
        <ol class="carousel-indicators">
            <li data-target="#myCarousel" data-slide-to="0" class="active"></li>
            <li data-target="#myCarousel" data-slide-to="1"></li>
        </ol>

        <!-- Wrapper for slides -->
        <div class="carousel-inner" role="listbox">
            <div class="item active">
                <img src="<?php echo get_template_directory_uri(); ?>/img/holiday-vacation-hotel-luxury.jpg" alt="Chania">
                <div class="carousel-caption">
                    <h3>Nice Hotel</h3>
                    <p>The atmosphere in Chania has a touch of Florence and Venice.</p>
                </div>
            </div>

            <div class="item">
                <img src="<?php echo get_template_directory_uri(); ?>/img/hat_and_flipflops_on_the_beach_204117.jpg" alt="Chania">
                <div class="carousel-caption">
                    <h3>Chania</h3>
                    <p>The atmosphere in Chania has a touch of Florence and Venice.</p>
                </div>
            </div>
        </div>

        <!-- Left and right controls -->
        <a class="left carousel-control" href="#myCarousel" role="button" data-slide="prev">
            <span class="glyphicon glyphicon-chevron-left" aria-hidden="true"></span>
            <span class="sr-only">Previous</span>
        </a>
        <a class="right carousel-control" href="#myCarousel" role="button" data-slide="next">
            <span class="glyphicon glyphicon-chevron-right" aria-hidden="true"></span>
            <span class="sr-only">Next</span>
        </a>
    </div>
    <!--End Carousel-->

    <!--Start Style-->
    <div class="style">
        <div class="container">
            <div class="row">
                <div class="box">
                    <div class="col-lg-6 col-md-6 col-sm-12">
                        <h2>Create A Modern Style <br />
                            <span>With Our</span>
                            Furniture</h2>
                    </div>
                    <div class="col-lg-6 col-md-6 col-sm-12">
                        <p>Duis aute irure dolor in reprehenderit in voluptate velit esse cillum dolore eu fugiat nulla pariatur. Excepteur sint occaecat cupidatat non proident, sunt in culpa qui officia deserunt mollit anim id est laborum.</p>
                        <ol>
                            <li>Mollit anim id est laborum</li>
                            <li>Mollit anim id est laborum</li>
                            <li>Mollit anim id est laborum</li>
                            <li>Mollit anim id est laborum</li>
                            <li>Mollit anim id est laborum</li>
                            <li>Mollit anim id est laborum</li>
                            <li>Mollit anim id est laborum</li>
                        </ol>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <!--End Style-->
    <!--Start Meet Our Team-->
    <div class="meet text-center">

        <h3>Meet Our Team</h3>
        <div class="conainer" style="margin:20px;">
            <div class=" col-sm-12 row">
                <div class="col-sm-4">
                    <div class="col-sm-12 text-center">
                        <img alt="" class="img-responsive img-rounded" src="<?php echo get_template_directory_uri(); ?>/img/images%20(1).jpg">

                        <div class="caption">
                            <h4>Adam Sander</h4>
                            <i class="fa fa-facebook fa-2x"></i>
                            <i class="fa fa-twitter fa-2x"></i>
                            <i class="fa fa-google fa-2x"></i>
                        </div>
                    </div>
                </div>

                <div class="col-sm-4">
                    <div class="col-sm-12 text-center">
                        <img alt="" class="img-responsive img-rounded" src="<?php echo get_template_directory_uri(); ?>/img/images.jpg">

                        <div class="caption">
                            <h4>Adam Sander</h4>
                            <i class="fa fa-facebook fa-2x"></i>
                            <i class="fa fa-twitter fa-2x"></i>
                            <i class="fa fa-google fa-2x"></i>
                        </div>
                    </div>
                </div>

                <div class="col-sm-4">
                    <div class="col-sm-12 text-center">
                        <img alt="Lorem ipsum dolor sit amet, consectetur" class="img-responsive img-rounded" src="<?php echo get_template_directory_uri(); ?>/img/download.jpg">

                        <div class="caption">
                            <h4>Adam Sander</h4>
                            <i class="fa fa-facebook fa-2x"></i>
                            <i class="fa fa-twitter fa-2x"></i>
                            <i class="fa fa-google fa-2x"></i>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <!--End Meet Our Team-->
    <!--Start Services-->
    <div id="services">
        <div class="container text-center">
            <h3>Services</h3>
            <p>Beatiful flowers in Kolymbari, Crete.</p>
            <div class="row">
                <div class="col-md-4 col-sm-12">
                    <div class="link">
                        <i class="fa fa-leaf fa-3x"></i>
                        <h2>New Design</h2>
                        <p class="text">Duis aute irure dolor in reprehenderit in voluptate velit esse cillum dolore eu fugiat nulla pariatur.</p>
                        <input type="submit" value="Read More....">
                    </div>
                </div>
                <div class="col-md-4 col-sm-12">
                    <div class="link">
                        <i class="fa fa-users fa-3x"></i>
                        <h2>Laravel</h2>
                        <p class="text">Duis aute irure dolor in reprehenderit in voluptate velit esse cillum dolore eu fugiat nulla pariatur.</p>
                        <input type="submit" value="Read More....">
                    </div>
                </div>
                <div class="col-md-4 col-sm-12">
                    <div class="link">
                        <i class="fa fa-database fa-3x"></i>
                        <h2>MYSQL</h2>
                        <p class="text">Duis aute irure dolor in reprehenderit in voluptate velit esse cillum dolore eu fugiat nulla pariatur.</p>
                        <input type="submit" value="Read More....">
                    </div>
                </div>

            </div>
        </div>
    </div>
    <!--End Services-->
    <!--Start Sing Up-->
    <div class="sing-up">
        <div class="container text-center">
            <h2>Sing Up Our Newsletter</h2>
            <p>Duis aute irure dolor in reprehenderit in voluptate velit esse cillum dolore eu fugiat nulla pariatur.</p>
            <input type="email" name="email" placeholder="Enter Your Email To Update">
            <button class="btn btn-danger">Sing Up</button>
        </div>
    </div>
    <!--End Sing Up-->
    <!--Start Footer-->
    <div class="footer">
        <div class="fonts text-center">
            <i class="fa fa-facebook fa-2x"></i>
            <i class="fa fa-twitter fa-2x"></i>
            <i class="fa fa-google-plus fa-2x"></i>
            <i class="fa fa-instagram fa-2x"></i>
            <i class="fa fa-linkedin fa-2x"></i>
            <i class="fa fa-twitter fa-2x"></i>
            <i class="fa fa-pinterest-p fa-2x"></i>
            <i class="fa fa-github fa-2x"></i>
        </div>
        <div class="footer-menu text-center">
            <ul>
                <li><a href="#">Home</a></li>
                <li><a href="#">Gallery</a></li>
                <li><a href="#services">Services</a></li>
                <li><a href="#">Contact Us</a></li>
                <li><a href="#">About</a></li>
            </ul>
        </div>
        <div class="copy-right text-center">
            Copy &copy; All Right Received By <span>Enas Ellithy</span> 2016
        </div>
    </div>
    <!--End Footer-->
    <!--
    <script src="js/jquery-1.12.1.min.js"></script>
    <script src="js/bootstrap.min.js"></script>
    <script src="js/jquery.nicescroll.min.js"></script>
    <script src="js/plugins.js"></script>
    <script src="js/wow.min.js"></script>
    <script>new WOW().init();</script>
-->
<?php wp_footer(); ?>
</body>

</html>